﻿using CleanArch.Core.Entities;

namespace CleanArch.Application.Interfaces
{
    public interface IContactRepository : IRepository<Contact>
    {
    }
}
